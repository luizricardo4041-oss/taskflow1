# Roteiro do vídeo pitch — até 4 minutos

**0:00–0:30 | Apresentação**  
Olá! Este é o TaskFlow, um sistema web de gerenciamento de tarefas desenvolvido para a empresa fictícia TechFlow Solutions. O objetivo é organizar demandas, prioridades e o andamento do trabalho.

**0:30–1:10 | Metodologia e Kanban**  
Utilizamos Kanban para visualizar o fluxo de trabalho em A Fazer, Em Progresso e Concluído. O quadro permite identificar prioridades e acompanhar o que está parado ou finalizado.

**1:10–2:10 | Demonstração do sistema**  
Mostrar o painel. Cadastrar uma tarefa, definir prioridade, editar o status, pesquisar pelo título e demonstrar a exclusão. Explicar os indicadores de tarefas.

**2:10–2:50 | Testes automatizados**  
Explicar que os testes com Pytest verificam carregamento da página, cadastro, validação de título, atualização, exclusão e busca.

**2:50–3:20 | GitHub Actions**  
Abrir a aba Actions e mostrar a execução do workflow. Explicar que cada push ou pull request dispara os testes automaticamente.

**3:20–3:45 | Mudança de escopo**  
Explicar que a busca textual e o filtro por status foram adicionados para facilitar a localização de tarefas quando o volume cresce. Mostrar o card correspondente no Kanban e o teste.

**3:45–4:00 | Encerramento**  
O projeto demonstra como planejamento ágil, versionamento, testes e integração contínua contribuem para um software mais organizado e confiável.
