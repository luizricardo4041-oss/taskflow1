# Roteiro de commits semânticos

Faça os commits ao longo das etapas reais de publicação. A atividade exige pelo menos 10 commits claros.

1. `docs: adiciona descrição inicial do TaskFlow`
2. `chore: configura estrutura do projeto Flask`
3. `feat: cria banco SQLite e modelo de tarefas`
4. `feat: implementa cadastro e listagem de tarefas`
5. `feat: adiciona edição e exclusão de tarefas`
6. `style: cria interface responsiva do painel`
7. `test: adiciona testes das operações CRUD`
8. `ci: configura pipeline de testes no GitHub Actions`
9. `feat: adiciona indicadores de tarefas por status`
10. `feat: implementa busca e filtro por status`
11. `docs: registra mudança de escopo e diagramas UML`
12. `docs: finaliza instruções de execução e apresentação`

Exemplo de execução:
```bash
git add README.md
git commit -m "docs: adiciona descrição inicial do TaskFlow"
```
Repita o processo depois de implementar cada etapa. Não crie commits que não correspondam a alterações reais.
