# Relatório teórico — TaskFlow

## 1. Descrição do projeto e escopo inicial
O TaskFlow é um sistema web de gerenciamento de tarefas proposto para a empresa fictícia TechFlow Solutions, que atende uma startup de logística. O sistema permite cadastrar, consultar, editar e excluir tarefas, definir prioridades e acompanhar o status de cada atividade. O escopo inicial contempla o CRUD e um painel com indicadores básicos.

## 2. Metodologia ágil utilizada
Foi escolhido o Kanban por sua simplicidade visual e adequação ao acompanhamento contínuo. As atividades são organizadas em A Fazer (To Do), Em Progresso (In Progress) e Concluído (Done). O quadro torna o fluxo transparente, facilita a identificação de gargalos e permite reorganizar prioridades conforme a necessidade do cliente.

## 3. Importância da modelagem na Engenharia de Software
A modelagem ajuda a compreender o problema antes da implementação, delimita responsabilidades e comunica a estrutura do sistema. O diagrama de casos de uso apresenta as funcionalidades disponíveis ao usuário. O diagrama de classes representa os principais elementos do domínio e suas relações. Esses modelos reduzem ambiguidades e apoiam manutenção e evolução.

## 4. Diagrama de Casos de Uso
O ator Usuário interage com o TaskFlow para cadastrar, visualizar, editar e excluir tarefas, definir prioridade, atualizar status, pesquisar e consultar indicadores. O diagrama correspondente está em `uml-casos-de-uso.mmd`.

## 5. Diagrama de Classes
A classe Tarefa representa os dados de cada atividade. GerenciadorTarefas coordena listagem, busca, filtros e indicadores, enquanto BancoDeDados abstrai a persistência. O diagrama correspondente está em `uml-classes.mmd`.

## 6. Mudança de escopo
Durante a simulação do projeto, foi identificada a necessidade de localizar tarefas rapidamente. Por isso, o escopo foi ampliado com busca textual e filtro por status. A mudança foi registrada no README e prevista como card adicional no Kanban. A funcionalidade também possui teste automatizado.

## 7. Testes automatizados
Foram preparados testes com Pytest para verificar carregamento da página, cadastro de tarefa, rejeição de título vazio, atualização de status, exclusão e busca. Os testes utilizam banco SQLite temporário, isolando os dados de teste. O GitHub Actions instala as dependências e executa a suíte em push e pull request.

## 8. Principais riscos e contribuição do GitHub
Falhas em projetos ágeis podem ocorrer por comunicação insuficiente, prioridades pouco claras, tarefas grandes ou falta de validação frequente. GitHub Projects torna o trabalho visível; Issues e Pull Requests registram decisões e revisões; commits preservam o histórico; Actions automatiza verificações.

## 9. Beneficiados pelo sistema
Os principais beneficiados são membros da equipe, líderes de projeto e responsáveis pela operação. A equipe consulta e atualiza suas atividades; líderes acompanham prioridades e volume de trabalho; gestores observam a distribuição de tarefas e o andamento das entregas.

## 10. Desafios ao implementar mudanças
Mudanças podem afetar prazo, esforço e funcionalidades existentes. Para lidar com elas, é necessário registrar a justificativa, avaliar impacto, priorizar o novo requisito, atualizar o Kanban, implementar em uma alteração rastreável e executar testes de regressão.

## 11. Aplicação das metodologias ágeis
O Kanban é aplicado na organização das tarefas e na visualização do fluxo. A priorização orienta a ordem de execução, enquanto entregas pequenas e testes frequentes ajudam a validar o produto continuamente.

## 12. Considerações finais
O TaskFlow integra planejamento, desenvolvimento, versionamento e qualidade. A experiência demonstra que ferramentas ágeis e automação ajudam a reduzir falhas e a manter o desenvolvimento transparente. O sistema é um protótipo acadêmico e pode evoluir com autenticação, colaboração multiusuário e hospedagem.
