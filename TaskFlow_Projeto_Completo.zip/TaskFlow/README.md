# TaskFlow — Gestão inteligente de tarefas

Sistema web acadêmico de gerenciamento de tarefas desenvolvido em Python com Flask e SQLite para a empresa fictícia TechFlow Solutions.

## Objetivo
Permitir que uma equipe acompanhe atividades, priorize demandas e visualize o andamento do trabalho em um único painel.

## Escopo inicial
- Criar, consultar, editar e excluir tarefas (CRUD).
- Definir prioridade (Baixa, Média ou Alta).
- Atualizar status (A Fazer, Em Progresso e Concluída).
- Visualizar indicadores de quantidade por status.

## Metodologia
Foi adotado Kanban, com fluxo visual em três etapas: A Fazer, Em Progresso e Concluído. O quadro é usado para limitar trabalho em andamento e tornar bloqueios visíveis.

## Mudança de escopo simulada
Após a definição do escopo inicial, foi incluída a funcionalidade de **busca textual e filtro por status**. A mudança foi motivada pela necessidade de localizar rapidamente tarefas em equipes com maior volume de atividades. A alteração foi registrada como novo item no Kanban e coberta por teste automatizado.

## Tecnologias
- Python 3.12 e Flask
- SQLite
- HTML5 e CSS3
- Pytest
- GitHub Actions

## Como executar localmente
1. Instale Python 3.10 ou superior.
2. Crie e ative um ambiente virtual:
   - Windows: `python -m venv .venv` e `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` e `source .venv/bin/activate`
3. Instale as dependências: `pip install -r requirements.txt`
4. Execute: `python app.py`
5. Acesse `http://127.0.0.1:5000`.

O banco `taskflow.db` é criado automaticamente na primeira execução.

## Como executar os testes
```bash
pytest -v
```

## Estrutura
```text
TaskFlow/
├── .github/workflows/tests.yml
├── docs/
├── src/
│   ├── app.py
│   ├── templates/index.html
│   └── static/style.css
├── tests/test_app.py
├── app.py
├── requirements.txt
└── README.md
```

## Kanban sugerido (criar em GitHub Projects)
Crie as colunas **To Do**, **In Progress** e **Done** e cadastre os cards listados em `docs/kanban.csv`. Mova os cards conforme o desenvolvimento real.

## Histórico de commits
O arquivo `docs/commits-sugeridos.md` contém uma sequência de pelo menos 10 commits. Execute-os em etapas durante o desenvolvimento; não use commits fictícios ou datas retroativas.

## Qualidade e integração contínua
O workflow em `.github/workflows/tests.yml` instala as dependências e executa `pytest -v` a cada push e pull request para `main` ou `master`.

## Limitações da versão acadêmica
A aplicação é um protótipo local: não possui autenticação, hospedagem pública ou banco de dados em nuvem. Não utilize dados pessoais ou confidenciais.

## Equipe
Projeto individual acadêmico — UniFECAF.
